def project_context(request):
    context = {
        "my_email" : "princeyekpahi@gmail.com"
    }
    return context