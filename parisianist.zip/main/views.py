from django.shortcuts import render


def home(request):
    message = "www.parisianist.fr"
    context = {
        "message": message
    }
    return render(request, "main/home.html", context)