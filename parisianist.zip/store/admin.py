from django.contrib import admin

from store.models import Product

# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'product_name', 'product_price', 'product_description', 'product_cleaning',  'is_active', 'updated',]
    prepopulated_fields = {'product_slug': ('product_name',),}
    class Meta:
        model = Product

admin.site.register(Product, ProductAdmin)
