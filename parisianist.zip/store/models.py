from django.db import models
from django_ckeditor_5.fields import CKEditor5Field


# Create your models here.
class Product(models.Model):
    product_name = models.CharField(max_length=500)
    product_slug = models.SlugField(null=False, blank=False)
    product_price = models.PositiveIntegerField()
    product_description = CKEditor5Field('Description', config_name='extends')
    product_cleaning = CKEditor5Field('Cleaning', config_name='extends')
    is_active = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now_add=True)